from django.apps import AppConfig


class ChallengesConfig(AppConfig):
    name = 'challenges'
